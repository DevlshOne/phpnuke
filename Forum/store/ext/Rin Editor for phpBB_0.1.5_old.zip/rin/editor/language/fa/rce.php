<?php

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	// Front
	'RCE_RESTORE'					=> 'بازیابی',
	'RCE_MORE'						=> 'بیشتر',
	'RCE_INSERT_A_VIDEO'			=> 'لینک ویدیو را وارد کن',
	'RCE_ENTER_URL'					=> 'وارد کردن آدرس:',
	'RCE_ENTER_THE_IMAGE_URL'		=> 'وارد کردن آدرس عکس:',
	'RCE_DESCRIPTION_OPTIONAL'		=> 'توضیح (اختیاری):',
	'RCE_INSERT'					=> 'وارد کردن',
	'RCE_VIDEO_URL'					=> 'آدرس ویدیو یا ای دی:',
	'RCE_QUICK_QUOTE'				=> 'متن نقل قول',

	// ACP
	'ACP_RCE_TITLE'			=>	'ویرایشگرانجمن',
	'ACP_RCE_SETTING'		=>	'تنظیمات مربوط به ویرایشگر انجمن',
	'RCE_CONFIG_UPDATE'		=>	'تنظیمات با موفقیت انجام شد.',
	'RCE_SETTING_SAVED'		=>	'تنظیمات با موفقیت انجام شد.',
	'RCE_LANGUAGE_TITLE'	=>	'زبان پیش فرض ویرایشگر',
	'RCE_LANGUAGE_DESC'		=>	'زبان ویرایشگر انجمن را مشخص کنید.',
	'RCE_BBCODE_TITLE'		=>	'انتخاب BBCode',
	'RCE_BBCODE_DESC'		=>	'BBCode مورد نظر جهت استفاده برای گروه خاص',
	'RCE_PBBCODE_TITLE'		=>	'دسترسی گروه برای ',
	'RCE_PBBCODE_DESC'		=>	'گروهی که دوست دارید از بی بی کد مورد نظر استفاده کنید.<br /><strong>پی نوشت.</strong> اگر گروهی را انتخاب نکنید تمامی گروه ها میتوانند از بی بی کد مورد نظر استفاده نمایند.',
	'RCE_MOBMS_TITLE'		=>	'استفاده در دستگاه ها موبایل',
	'RCE_MOBMS_DESC'		=>	'با انتخاب گزینه بله ، کاربرانی که از دستگاه موبایل استفاده میکنند نیز میتوانند ویرایشگر را مشاهده نمایند.',
	'RCE_ENBQUICK_TITLE'	=>	'نمایش ویرایشگر در پاسخ سریع و ویرایش سریع',
	'RCE_ENBQUICK_DESC'		=>	'با انتخاب گزینه بله ، ویرایشگر در پاسخ سریع و ویرایش سریع نیز قابل استفاده است.',
	'RCE_SCSMILEY_TITLE'	=>	'قالب SCEditor برای شکلک ها',
	'RCE_SCSMILEY_DESC'		=>	'با انتخاب گزینه بله ، قالب ویرایشگر SCEditor برای شکلک ها استفاده خواهد شد.',
	'RCE_AUTOSAVE_TITLE'	=>	'قابلیت ذخیره خودکار',
	'RCE_AUTOSAVE_DESC'		=>	'با انتخاب گزینه بله ، قابلیت ذخیره خودکار برای ویرایشگر فعال می شود.',
	'RCE_AUTOSAVEMSG_TITLE' =>	'اطلاعیه خودکار',
	'RCE_AUTOSAVEMSG_DESC'	=>	'با انتخاب گزینه بله ، اطلاعیه خوکار در قالب یک باکس برای کاربر  نمایش داده می شود',
	'RCE_QUICKQUOTE_TITLE'	=>	'قابلیت نقل قول سریع',
	'RCE_QUICKQUOTE_DESC'	=>	'با انتخاب گزینه بله ، قابلیت نقل قول سریع برای ویرایشگر فعال خواهد شد.',
	'RCE_SUPSMENT_TITLE'	=>	'پشتیبانی از افزونه اشاره سریع',
	'RCE_SUPSMENT_DESC'		=>	'با انتخاب گزینه بله ، ویرایشگر از افزونه اشاره سریع پشتیبانی خواهد کرد.',
	'RCE_HEIGHT_TITLE'		=>	'ارتفاع ویرایشگر',
	'RCE_HEIGHT_DESC'		=>	'ارتفاع جعبه متن ویرایشگر را بر حسب پیکسل تعیین کنید.',
	'RCE_SUPEXT_TITLE'		=>	'پشتیبانی از دکمه های خارجی در ویرایشگر',
    'RCE_SUPEXT_DESC'		=>	'با نتخاب گزینه بله ، ویرایشگر از دکمه های خارجی پشتیبانی خواهد کرد<br /><strong>پی نوشت.</strong> این قابلیت در مرکز میدریت ، پاسخ سریع و ویرایش سریع کار نمیکند.',
	'RCE_DESNOPOP_TITLE'	=>	'غیر فعال کردن حالت پاپ آپ دکمه ها',
	'RCE_DESNOPOP_DESC'		=>	'با انتخاب گزینه بله ، حالت پاپ آپ توضیحات برای دکمه ها غیر فعال می شود.',
	'RCE_PARTIAL_TITLE'		=>	'حالت جزئی',
	'RCE_PARTIAL_DESC'		=>	'با انتخاب گزینه بله ، حالت جزئی برای ویرایشگر فعال خواهد شد.<br /><strong>پی نوشت.</strong> این قابلیت تگ ها نقل قول و کد ها را در ویرایشگر تبدیل نمی کند.',
	'RCE_SELTXT_TITLE'		=>	'جایگزین نکردن متن انتخابی',
	'RCE_SELTXT_DESC'		=>	'با نتخاب گزینه بله ، متون انتخابی شما جایگزین تگ ها نخواهد شد',
	'RCE_RMV_ACP_COLOR_TITLE'	=>	'حذف رنگ انتخابی',
	'RCE_RMV_ACP_COLOR_DESC'	=>	'با انتخاب گزینه بله رنگ های انتخابی شما در مرکز مدیریت برای آن حذف خواهند شد.',
	'RCE_CACHE_TITLE'		=>	'نهانگاه',
	'RCE_CACHE_DESC'		=>	'زمان پاک کردن نهانگاه (  کش ) بر حسب ثانیه مشخص شود. اگر 0 انتخاب شود یعنی غیر فعال است. حداکثر مقدار مجاز 86400 است.',	
	'RCE_IMGUR_TITLE'		=>	'آپلود عکس از Imgur',
	'RCE_IMGUR_DESC'		=>	'َAPI  آپلودر عکس را وارد کنید.<br /><strong>Ps.</strong> کلاینت ای دی را از اینجا دریافت کنید https://imgur.com/register/api_anon ',
	'RCE_SKIN_TITLE'		=>	'تغییر پوسته',
	'RCE_SKIN_DESC'			=>	'نام پوسته را وارد کنید. <br /><strong>محل قرارگیری پوسته:</strong> root/ext/rin/editor/styles/all/template/js/skins/',
));
